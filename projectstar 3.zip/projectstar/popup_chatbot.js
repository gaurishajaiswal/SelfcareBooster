const popup = document.querySelector('.popup');
const floatActionBtn = document.querySelector('.float');
const sendMsgBtn = document.querySelector('.submit');
const chatbotArea = document.querySelector('.textarea');
const textInput = document.querySelector('#msg');
let questions = {"yes":"Are you feeling sad lately?",
"yeah":"Have you passed the quiz or failed ??",
"passed":"Congrats,Its mean your Mental Health Status is Normal For further queries mail us, Thank You!","failed":"I appreciate your effort, you don't need to worry we will take care of you, Thank You!",
"nope":"Ahhh! in case you need any help, mail us at praful.yadav_cs20@gla.ac.in",
"no":"Are you a patient and wanna check any information?",
"y":"All the specific information regarding Mental Health Care centres and Patient are open to you! Check it now, in case of further queries mail us! Thankyou, for your time!",
"n":"We have no information other than Our patient and Doctors. Mail us at praful.yadav_cs20@gla.ac.in for further queries. Thankyou for your time!"};
var arr=new Array();

floatActionBtn.addEventListener('click', ()=>{
    popup.classList.toggle('show');
});

sendMsgBtn.addEventListener('click', ()=>{
    let userText = textInput.value;
    let creatingUserBlock = `<div class='userSideMsg'>
                                <span class="userActualMsg">${userText}</span>
                                <img src="pat.png" class="avatar">
                            </div>`;

    chatbotArea.insertAdjacentHTML("beforeend", creatingUserBlock);
    userText=userText.toLowerCase();
    if(questions[userText] && (!arr.includes(userText))){
        let roboText=questions[userText];
        let creatingRoboBlock = `<div class="roboside">
                                        <img src="doc.jpeg" class="avatar" alt="">
                                        <span class="robomsg">${roboText}</span>
                                    </div>`;
        chatbotArea.insertAdjacentHTML("beforeend", creatingRoboBlock);
        if(userText=="yes"){
            arr.push("yes");
            arr.push("no");
            arr.push("y");
            arr.push("n");
            document.getElementById('msg').placeholder="Yeah or Nope";     
        }else if(userText=="no"){
            arr.push("yes");
            arr.push("no");
            arr.push("yeah");
            arr.push("nope");
            arr.push("passed");
            arr.push("failed");
            document.getElementById('msg').placeholder="y or n";   
        }else if(userText == "yeah"){
            arr.push("yeah");
            arr.push("nope");
            document.getElementById('msg').placeholder="passed or failed";
        }else if(userText == "nope"){
            arr.push("yeah");
            arr.push("nope");
            arr.push("passed");
            arr.push("failed");
            document.getElementById('msg').placeholder="";
        }else if(userText == "passed"){
            arr.push("passed");
            arr.push("failed");
            document.getElementById('msg').placeholder="";
        }else if(userText ==  "failed"){
            arr.push("passed");
            arr.push("failed");
            document.getElementById('msg').placeholder="";
        }else if(userText=="y"){
            arr.push("y");
            arr.push("n");
            document.getElementById('msg').placeholder="";
        }else if(userText=="n"){
            arr.push("y");
            arr.push("n");
            document.getElementById('msg').placeholder="";
        }
    }
    else{
        let roboText="I don't understand you! Please respond as per given texts in chatbox.";
        let creatingRoboBlock = `<div class="roboside">
                                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFRYYGBgYGRgaHBgcGhgYHhwZGh0ZGhwYHBwcIy4lHCErIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHzQrJSw0NTE0NDExPzY0NjQ0NDE0NDQ0MTQ0ND00NDQ2NDQ0NDQ0MTQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAPoAyQMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcBAgj/xABAEAACAQIDBQUGAgoBAwUAAAABAgADEQQSIQUGMUFRImFxgZETMlKhscEHQiNicoKSssLR4fAUJDRjFTM1c/H/xAAaAQEAAgMBAAAAAAAAAAAAAAAABAUBAgMG/8QALBEAAgIBAwMCBQUBAQAAAAAAAAECEQMEITESUXEiQQUygZGxE2Gh0fDBI//aAAwDAQACEQMRAD8A7NERAEREAREQBERAEREAREQD5lY2vvrhqDNTuXddCFtYNxylieOvK80N/d7xhlOHom+JqKbW19mvNz366DznIdkbPxFTM7Kcpa4Y3FzwNr8eA15zSUlFcm8IOXCOoj8QWAP6JXP5SGItbQhhb6Wlj2DvTSxIt7j2vlJGvLsnnrOF0axRyr++SRp1HA9wsJtYSuaxuASRfKQpWyjmP7zCk+TLiuD9F3nso2423KrfoK5zEKCjniwF7hiOfQmXibp2aNUexETJgREQBERAEREAREQBERAEREA8iQu8eNVEVWz5qhKpl45wCRzF/wDErlTG1SgWrULW+FbMwsPetoDxuefdOc8ijydceGU3sXyDOc09qYhLuquFHU5l16hjofSWfYW8K1gyvZXQAkk2Ug31F/DUctIjlUjbJglBXyiwTS2rjBRo1KxFwiM1uthe3nN28qH4nV8mAfjZnpqbX4Fh8tBN3wcUUXZCHE4mvXfVnCqzc8puWRT+UcBp0lxTB3QKqgKBYADgO7pKtuZTPsfaHRWJyjmQCReWobVpJZWfITwuCM3hprIEl1TdlpjXRjVe5T9s7uB2JChTyNpFDZ7076sSNQoNh/kDoZfa1bNc5lI1APC5BAt6kSqiuTiaQ+J09CwFpvDqTr2MZoQceqtx+H+NJxuZnZtMtiCRY2sy2OljpYgc52kTi27uGKbfxC27JLXHLtFTe3iJ2kSWitkexETY1EREAREQBERAEREAREQBERAKzvPb2lCw7Qz69FIAI+npMNbDI62I5WFtD3aife1znxAUa5UA82JJ+Vp5tKuKVMnnbTxkSXqkywxbQSXJAYjBVqyVKVFGKq6hiHCgsCCw1PaIAt4kSBw+7NeqxoA1adS929oMyZNA1mAupsdBrfWxBE6tsTDGnQpofeCgt+03ab5kzfnaOOqOE87tpIo3sNp4VVyMuJRRYq3aaw4WJIY6eMr+8G9nt1/4+MoVKAs+YLdg5y2W9wGABN7dQNZ1qQe8WzkqqudFcLmBuL2BtwPEcJtP5Tli+ZFO2BhXWgiZSpCDQjge8GR+3dn4qsFRHQqvE5COfXMflLNs6vrmve54zBhcW9aozpZaSEqvL2lQaHXkinnzPhrDj3LN1VPsV3fCs9HChKd81+J4m5BN/wDekq+BxIWrRcPVZw6MbrcDKQdAo11lg342pTdMgIzgahTms2vPhxkTsWqgFNiL8Dpoe/XlrOkNq8nLKk/sXndbAl9qYivbsoo48c9RQ2Xyu/rOiyl/htQY0KmIe98RVZxfjkWyrrzBIY+cuklLuV8uT2IiZNRERAEREAREQBERAERPIAmhtPGikl7XY6KvVuQ8OZPSbOIrqilmNgOMra1GdzVfS1wo+Feg7zzM5zn0qlydcWPqdvgyYan7NSzHMzXZm6sfoBwAmHZuCbEOKri1JWuoPFyODdy39bTBiqmeomHXi57XcnFvlLfTphQANAAAB4TTHG9zvmm4Kly/wZBPYidyGeTFVcKCWIAA1JNgPEmZZC7zZHoPRcj9MrIBpckjiBztxms2oxbZtFNukVPBP2GH7VvO5B+c8wOGrUktm/RexTKoAUq494M2U6HiCRxvMGCxIyhiRe2RrcM6XB9eUlq1RTStm4jrIUCz24OZ7eZixVaZU3zFmyZQDxsVALMZvbA2Kz1aWHXR8md+iZtdfAETBtXV7KSdZsYfbdTAYmk4syVFDVhYEkO3C/EEAAi33neK4s5Ttt9J27B0AiKi2ARVUWFhYADQTYmvhMUtRFdDdWAIPcRcTYkgrxERAEREAREQBERAEREA+ZVN4t7lw7GmoD1LAgE5VuTYLfUknpJ3aLnsqCRc6kdBy85y/ZOznrbWxD19RRIFMD3QCOyRfnlPqTI08j6ulbUStPji/VNWuxc6VerXVWrKFsL+zUlhfqTzP01nuMq5FzHjyEkggC35DhKztqqTpcDu4n0/vac5zUVcmSccep1BEvupg/fxL+89wpPJRx+nykntDb1CiuZqim/AKQxY9ABOf7R3walRXDi4YLYsANV1tf4fKa26WwWxGd3VlAfgRbssLgjqOMkY5RcV0kTLjkpNyOibP201cg06LBD+dmVb+Ci59bTbetUN8qqLcb3P9pmwWGFNFUcAAPSZUWxPfrOpw2NHZ6vc52diObKEHgAOPjILb2U4okr2kw4Ktr+ZnzAfwLfyltAlK37xnsXWotixpVVCm9mOanYaefzkfUpvG0iRpFeVIqexKop0nNYgqjOlW+umYsr+NmA8COk1NotbWjVZkOoF7i3ceYm3hXT2lTMLpUpoxVhxRviHUBtfCRi4VcM5XtMmbQAX7LfmDE2BB4g2BvcHiBFi21+5ZZYdEt+PwRlUsp1uSeAHE90jNqYlnJLa27OnCy6WHcJZdqbZwjK5pMz1XUoi5GXKLEXzMAOPS50FpHbD3Wd0BclRyFtT3m/Cb/qdKue3/TWEU36d+7Okbk4urTwtJnU+zFJDnAJupA1yi5IHa1Alrw+2qbfmXW1iGBvfhpxHhaebLoCnQoKOCIieFlAB/wB6z3Zv6T2jMAR7RlUFRoE7N787kEydF2kVE66n5JRSDqJ9TWtlNhMi1esyamWIiAIiIAiIgHk+KhNjbjbSfc+KjAAk8BrMPgIrm0MetJlSsWLVL5VALE5dTYLwmnXq5WD06bF2ABurLmHK7WNiNeM2DRWpU9s6jMCcp5heAHpc+c+8SwtqZSTyJSuP3LOCSpVv7mnidtg/o7lH4WYWH7p91j/tpDYqjdTcnTib8ZsbTCspDC46nTz7pBYeo1/ZPcsPdbmwtcA9DYfScm5ZHfuWGGEYR6lt3N/Yuw0q4jM4zLYXB68PtOkYTDIihEFgBoO6UrcWmzO1U3FxlKH8pUkeRHOXtZd4IuMEnyUurkpZG1wZIInsTsRjyU3fKlmr0B/46v8ANSlylX3mW9fD/s1h8kP2kfUq8TJWjl05k/P4KRTwr1cYzMLIQ6W090DKB8ppPWVKZStfOqtT4Xva6qxPK4sfOWynSAqXHG/3lY23SBLC13qVCinmLsczDwW58pVYcjcqf+ou5yjJO/ZbeSB2Nh6rolKmoGoPtALNe/xcQB0EvlOi4dgraD4hfhbmLH6zJsymruSgASn2VtwJHG30mZB22PjNM2VyfBraSpeyLphreyW/DKL+gkRurj89Ox4ipUv4ZiR9ZIV2y4Zj0pH+WVzdY5QCPzFmv3s9pfQ+VeDz8uX5LbV95e/MPl/iYwRlVj5xjny5D/5EH8V1+80drYr2dJf1iR5a/wCJsamzsbGe0QnmHceQNx8iJJStbtHKDfncnxYyywYEREAREQDyYqy3UjqDMsGYatUZTorikBbyKxWK45deuoAHix0E29v0KtO5RSyHU21K343HTvlTq1Q/vEsOl7CUGWEoSpoutNjWSPUmebT2iqjskM3Wxyg/qj8x8dO6Z93dmMzrUqE5iGOXjYkjUnm2hvNB1UG+l+VhYDvF9Wbv+Uu+yKJSkCwysbELzC20B7+fnJOlhc1XC3Z01c1jxUuXsbWGpigHYDQsCfGwF/kJMYV8125G0rO0cTmFr6Sc2CxNBGOpa5+ZA+QlsmUkltbJLnPqYwe15TJMnM+TKtt7EWxCJ0R2/lUfeWhjpOc7WxRfHuAdERF8zdj9RI2rl04mTNDDqyeEzfK2a/nKI+fEYx6aG1On7TM4PBSWLWPIknL4Ay3baxns0Z/gRj5gXHztIjcfBZMMHOr1g7sTx/MFHhxPnKnC+mLn9F9Sybdr7/YtmAoKiKqiyhRYTBRGrH/f9vM2Hqfo1PVV+gmPZQzOo6vc/sjtfVZziuqaRo21GUmWDboIwtQDQ5LethILdyiWw2VGUPYuhNyoYHmBqQbC47pO7yn/AKap4L/MsotfFPhab4hHYBVJROI9o5sFCnQ5mPAaz0SRTXsS9LFOHDO5cF1JU21INw3dz4aCeba2n7bIiW99xcajKFS7E+LH0mlSwz0sOq1XL1RSzVCwFw73cqGHIZrW7pg2InYF+ZY+V/8AE2CLVsvp8TADwUH7yxU2uBIDZSXcHkoJkxgqmYHxmDDNqIiDAiIgCIiAfNpF4rYWHqElqSkniQLH1FpKxNXFS2aMqUo7xdELhd3MPTOZUsw4MSWI8L3tNttmIeOY+LH7TfEQoqOyRlzlLeTs012bSH5F8xf6zaVQBYaeE+jE2NbMajtHwEyz4A1M+4B8tOR7Pre0xGJqci7W8FOUfICdT2hWyU3f4UZvQE/acg3SN8/XjIOvf/nRa/DI/NLwTG26ftMPUXmUYDzE292GDYagw+AAjoV7JHqDPij2ntyvaaeFxH/Dq5KmlGocyOeCubZgx5A6a9b/ABCVmP1QcfdOyTm2kvBKCvloL+wv0E290mvV/dJ+khKr3pp0yr9JYN0FGYt0U693ZmcG+deTOdJaeTJTexj/AMaoBxIQDzYSnbJojGYpVJvhsFlZjyqYhR2V71TUnv8ACZ96NvnEu2EwTBuAq4hdVpAE3Ctweob2AHCSG7GGSlTamgAVFyjqSeJPUz0BQ+w2s2dKz/GfkLAfITXwqALSUc0B+5+s3dtLlw7W6fcD7zS2MM9VBfUU1Fug5k/7ymTKLHSXJSv+Z9B4TewqZSq9VM16C53DflXRf7zaqH9Inn9JgwbsREGBERAEREAREQBERAPDPZ5PYB8859TwT2AQO+VfJgq5vYlCo8W7P3nOt0aOp7xLn+I9UjChR+d1HiB2vqBK7sOhkC3+E/Qn7Ss18+Il5oI9Oncu7/Bv7Mp3JY/EZmrYL2qkOuZOfDQE2E92UOz4kn1myjWyjkePfbhK2NKmbZW+p0UHGbAq0VX2deoqsfcBDgeCkG3lJXd/db/lhxVxVd1ULdM3s0a99GVACeEl1OeoSeCIP4nJ+w+cm9z6IArNbiyj0B/vJ2mySllUWc9SorA9t9vfbf8AYjqmyFwyBUCqg0CqLDx758bvuWqVByQXPiZI7be/8RPoP8z62NhwmHL21dvuRLcqL2Me8CWw/wDvUSJ3f/8AecH4UX90KCfUn5Se3hT/AKe3h9RK1u5igcVUH61vTT7TF7mUtrOg4SnYXI8JixThWQnr9dJ9VsbTpLeo6qAL6kCVvGb2YUtYOztyCIx495sJhyiuWI45y3Sb+hcZ7NLZuL9ogbKy8rMLE25jum5Njm1R7ERAEREAREQBERAPJ7PBBMACezwRAOf/AIk4mzUU7mY/ID7zyhZkpuODL8ytvqZFb/1S+MsPyqq+Zux/mEm8PQtRQdAPWUutac7/ANsegxrp02Nf7cw4N8trzZduHcZGs+pB0ufnNoksCRwFrm4HE6WHOQlb2RvKO9swYFrI7E+87+inIP5T6y0btU7UCbWLMx9LD7Sp4WyUh1LNqf2jLrskWw6nqCfUkyfoVeZvsiHr3WPyyF2ydB+99puoLJQTuLH/AH1kXtJ7tb/dTJWof0yL8KKPlf7y4KsbwH9F6fUTkm7WLq1MTUZWZRnc3Ww0zG3aPCdO3yxGTDVX+FGPoJzrdqrRwmHFau1jUOgF2Nuth5yJqpSUajy+Cbo4xduXCLHtDBK12Ny7e8xJJNuGpmru7gAMTTBQe8OpuQb3N+nTvmJt4MPV9yqtzwVrofRrSV3bxq/8imrAntdlhxBIIseo1PhK7B19aU759y0nJfotx7M6UBPqeCey8PNiIiAIiIAiIgCInkACfLnSfcxVTwgGQQZ4sMYBxrbWLzYyq3SqR/AQv9MuGfMgN+U5jVrFqzkfmqO38TE/edB2cxKC/SUOrVSvuekkk8cV22MWJS5BhmuQT1Bn3WWatVrG0iG8VaMeGW62J0zvbwzNL8Blw6ryyL9BOa4ZyQQL+84H8RAnScfZaYBNrBR6S1+Hx9UmV/xLZRXkgFXNXUd4m77S+IY99vTT7TUpMBiTfkAfkP7z3BPdyeploVTNvbFEVEdDrnV1tx4owGnjach3D2CuIRq1cswQ5UW5AHNr/wBp1/FVslnPJgfS8ou46lMEhPFyzn94mccrpEjBbZE7fwFJuCKvKwFtJYvwz3arqy16rKaIDNS7RLG91FxyA159JDbUcM9uhnWN2lthaP8A9an11muOKlyb5puPHvsSonsRJBCEREAREQBERAEREATDUYX1maa2I4wDKnCaW2q+TD1X+FHI8bG3zm7S4SA35rZcFV/WCr/EQJrN1Fs3xLqnFd2jjuz6YNVQeonScIgCCc2wCk1R3ETomEJyjwlFqvmXg9FP5fqfGKU3Fhz1ka9MnO4GiOqm5F7sQBYc+Mk6tXKCeesjWpKxFwDqD59ZHg4rlG0Lo93ew5Zqd+bL82vL5tY6MP1beolK2Big2IoovDN8lUn7S77QFy3UKbC17tbSW+gi+lyfuyr+It/qJPsVjE1P+pbrkUeeRZsYHjea3sc9ao+YdlQfHQDS0z0LA2uJYFezW3vxGXDPY2JR/XKZCYKn7PCUlHFUQeeUXmzvmxZAo5nL62H3kftWplQIOXO/2kbM7dEvAqjZCOSzgcSSPMnlO54Ghkponwqq+gAnHN0cKa2MpLyVs7eCdr6gDznbBOmJUjhnlbo9iInU4CIiAIiIAiIgCIiAeTVrnWbUj8Q3agyjdp8JXt/0vgqh+Eo3o6ywUuAkLvt/2OI/YP1Gs1mrizfE6yRf7o5HshQagPfL5hpSd26WZ73l3RABKDUP1noZPY1MRbXvkVUxVtRyJ+V5MVwBxYDxMquKDZSQQbtUuovdQDa58b6TTFC7OuNqtzf/AA6UvjEPJVdvll/qnSsZm7emnDNe2nCwA1JJ0lQ/DfCBXdgNcoHqf8S1YiuWcgcEbQdXGgJ7hxl5p6cLXcpPiDvPXZIrFenlxFVV0ANrDQcuU+q7sq30Nte+818Y2XEVdfztr5yM2tj+zZTrO10iMo2yOqVGqOgJ41Mx/duZg2/WJa172m7gEPYY/lVif3uEhtpVszmRpO5EuKqJd/wpwOtaue6mv8zf0zpEqv4dUFXBKV/OzsfXL/TLVJMVsQJu5M9iImxqIiIAiIgCIiAIiaIxbAsGpsoHBtGDDqLG484BuGRua76mbD4xLe8Bpz0+s0lcHXiONxrBmiSR7mw5TT3hpB8NWVuBpVL/AMJm3hR2YxaZkdbXurC3W4Okw+DMXTTOKbr1ba2MtFSozfmsDytKhuvX5S50jc9887qFWRnpb2TNYYXWxNzxM+TTCk24Xmw17kAamR9KuGaqo402CHn2soY/W3lOSTds2Ut6b5LbuUvZqNyuq+l7/USXwtDKWZtSzMQOgJPGaG5lArQc/E7HyAVfsZP2E9BpV04UUGrleaXn8HL9t4i1Wqerv9TICkc7ak2+s+94sUTWqgcqj/zGaex6lmS41dreQBN/lMzlSN8cbdE3iqoC9Li0qmNbU2k1teqQxHpIGodZygrds75HSo73uxhBSwtBF1Apqb9SwzE+pMlpFbsgjCYfNx9lTv8AwiSslorHyexETJgREQBERAEREAREQDUxOARxZl8xoZyDfPZlbZtQPQr1MlbMQAStmUglSB2TxuNORnaZpbU2bSxCGnWRainkeR5EHiD3iYoymcg2P+IeNUrnK1U5hkCtbuZbfSXmnvkrpfIe0CAVIIBI53sRKPvXuumDrotNmZKgZlDcUykArm5jWa60youjFT3fec8sZtel0/4OuGUE/WrX8mxsjZQpn0lmog26DnKgm32Q9tA47jlPzuJspv1hl0ZKq/uq30aU2XTZ3K2r8Fw9Xha9LryWgkLdvEk9w1M57uHjzUq4m599hUF9eLNf6rJjb29mGbC1fZ1O2yFVUqVa7dnS+ml7+Uhvw4wK+xrYixzJVpU730CVA3zL5PSdsOnksE+pU/6OEs8f1oU9v7Ou7B2vQp0VR6gVrtoQQeJPTpaSf/rOHAzGqoHU6D1M5ptSmCovY2fqBoQQTr5St4qtY6Gw04NpJGn1DcVGuBm0UXJyUuXZsY1C7uRrmZj6kmebHRmrrb3KStc8sxU6eQPzkM+PYAguLdNP/wBkvgdqFMMzsqKnuIqrkzX99uOuvPuM6ybaNYxUXyjVxFYvXZieyiXPiWsPv6SKXEM7lV4u4QeJNp94jEZKbsbBnZTk5hFByg+JYn0lj/DvcyvXr0q9RGShSYVLsCpdwcwCqRci4F24dLzpCJHyTrk7phqeVFX4VVfQATNETuQhERAEREAREQBERAEREAREQDnn4lr+kw5/Vq/VJVEEt/4le/hv2av9EqA4QCPx1ESqbUo2vLfjOBlY2rwMGSBSpcFG4cu4zqf4c7BersfHAi3tyQneaS3DD9/T92clqcZ+i/wf/wDiqX7db+d4MHGsOPOfb0ek8o+96zYWYozZpGjPo1TYBhmye5e9hrfUc5mqTC8dKZlSceD5TVwz9ok8TP0du3Xz4Wg17k00ueOoAB+k/OdLl4z9Abjf9jQ/ZP8AM0zSSNXJt7lhiIgCIiAIiIB//9k=" class="avatar" alt="">
                                        <span class="robomsg">${roboText}</span>
                                    </div>`;
        chatbotArea.insertAdjacentHTML("beforeend", creatingRoboBlock);
    }
    textInput.value = '';

});